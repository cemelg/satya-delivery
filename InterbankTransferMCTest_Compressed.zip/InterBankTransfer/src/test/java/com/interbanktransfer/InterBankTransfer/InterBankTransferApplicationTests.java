package com.interbanktransfer.InterBankTransfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterBankTransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
